@extends('admin.layouts.app')

@section('content')

 <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">All Customers</li>
      </ol>
    </section>

    <!-- view list of agents -->
    <!-- Main content -->
    <section class="content">
        @if(Session::has('flash_message'))
        <div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> {!! session('flash_message') !!}</em></div>
        @elseif(Session::has('flash_error'))
        <div class="alert alert-danger"><span class="glyphicon glyphicon-ok"></span><em> {!! session('flash_error') !!}</em></div>
        @endif

        <table id="customer" class="stripe row-border order-column" style="width:100%">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Customer Id</th>
                    <th>email</th>
                    <th>Date Of Birth</th>
                    <th>Father/Husband</th>
                    <th>Residential Address</th>
                    <th>Marital Status</th>
                    <th>Land Mark</th>
                    <th>phone_number</th>
                    <th>Police Station</th>
                    <th>Years[Res. Address]</th>
                    <th>Residance Type</th>
                    <th>Office Address</th>
                    <th>Ofc Phone Number</th>
                    <th>Adhar Card Number</th>
                    <th>Pan Card Number</th>
                    <th>Years[Office Address]</th>
                    <th>Profile</th>
                    <th>Total dependants</th>
                    <th>Loan Amount</th>
                    <th>EMI</th>
                    <th>Status</th>
                    <th>Period</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            @if(!empty($allCustomers) && isset($allCustomers))
                @foreach($allCustomers as $key => $customer)
                @php $key++;@endphp
                @if($customer->status == "0")
                @php $style = "style= background-color:#ffff99"; @endphp
                @elseif($customer->status == "1")
                @php $style = "style= background-color:#d9ffcc"; @endphp
                @else 
                @php $style = "style= background-color:#ffebe6"; @endphp
                @endif
                <tr <?= $style;?>>
                    <td>{{$key}}</td>
                        <td>{{$customer['name'] ? ucfirst($customer['name']): "NA" }}</td> 
                        <td>{{$customer->customer_id ? $customer->customer_id:"NA"}}</td>
                        <td>{{$customer->email ? $customer->email : "NA"}} </td>
                        <td>{{$customer->date_of_birth ? date('d-M-Y',strtotime($customer->date_of_birth)) : "NA"}}</td>
                        <td>{{$customer->father_or_husband_name ? ucfirst($customer->father_or_husband_name) : "NA"}}</td>
                        <td>{{$customer->residential_address ? $customer->residential_address : "NA"}}</td>
                        <td>{{$customer->marital_status ? ucfirst($customer->marital_status): "NA"}}</td>
                        <td>{{$customer->land_mark ? ucfirst($customer->land_mark) : "NA"}}</td>
                        <td>{{$customer->phone_number ? $customer->phone_number : "NA"}}</td>
                        <td>{{$customer->police_station ? ucfirst($customer->police_station) : "NA"}}</td>
                        <td>{{$customer->years_of_res_address ? $customer->years_of_res_address : "NA"}}</td>
                        <td>{{$customer->residance_type ? ucfirst($customer->residance_type) : "NA"}}</td>
                        <td>{{$customer->office_address ? $customer->office_address : "NA"}}</td>
                        <td>{{$customer->ofc_phone_number ? $customer->ofc_phone_number : "NA"}}</td>
                        <td>{{$customer->adhar_card_number ? $customer->adhar_card_number : "NA"}}</td>
                        <td>{{$customer->pan_card_number ? $customer->pan_card_number : "NA"}}</td>
                        <td>{{$customer->years_of_ofc_address ? $customer->years_of_ofc_address : "NA"}}</td>
                        <td>{{$customer->profile ? ucfirst($customer->profile) : "NA"}}</td>
                        <td>{{$customer->no_of_dependants ? $customer->no_of_dependants : "NA"}}</td>
                        <td>{{$customer->loan_amount ? $customer->loan_amount : "NA"}}</td>
                        <td>{{$customer->EMI ? $customer->EMI : "NA"}}</td>
                        <td>{{($customer->status == 0) ? "Pending" : (($customer->status == 1) ? "Approved": "Decline")}}</td>
                        <td>{{$customer->Period ? $customer->Period : "NA"}}</td>
                        <td>
                        @if($customer->status == 0)
                            <a href="{{url('update-customer-request/'.$customer->id.'/'.'2'.'/'.$customer->agentCustomer->phone_number)}}"><i class="fa fa-close" style="font-size:24px;color:red"></i></a>&nbsp;&nbsp;
                            <a href="{{url('update-customer-request/'.$customer->id.'/'.'1'.'/'.$customer->agentCustomer->phone_number)}}"><i class="fa fa-check"  style="font-size:22px;color:green" aria-hidden="true"></i></a>
                        @elseif($customer->status == 2)
                        <p>Decline<p> 
                        @else 
                        <p>Approved<p>
                        @endif 
                        </td>  
                    </tr>
                @endforeach
            @else
            <tr><p>USER NOT FOUND</p></tr>   
            @endif 
            </tbody> 
        </table>
    </section>    
    <!-- /.content -->


@endsection
@section('script')
<script>
 
    $(document).ready(function() {
        var table = $('#customer').removeAttr('width').DataTable( {
            scrollY:        "400px",
            scrollX:        true,
            scrollCollapse: true,
            paging:         true,
            columnDefs: [
                { width: 100, targets: 0 }
            ],
            fixedColumns: true
        });
    });   
 
</script>
@endsection	
 

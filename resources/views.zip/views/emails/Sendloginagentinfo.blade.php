Dear Sir/Mam, Now you can login in your account with your Uphar Finvest dashboard <br>
This is your emailid<strong>{{$useremail}}</strong>
<br>
This is your password <p>{{$password}}</p><br>
<h5> Please don't share your password from anyother </h5>
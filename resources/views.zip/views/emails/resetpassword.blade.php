Hi, This is request of user to change the password <br>
This is user's emailid<strong>{{$useremail}}</strong>
<br>
This is new password token to please set it for this user<p>{{$resettoken}}</p>